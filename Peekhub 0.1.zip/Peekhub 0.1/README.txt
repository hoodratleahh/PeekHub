Hi, this is the owner of the logger (Peekhub)

1st install python and make sure to click modify and tick all the boxes or the Peekhub Loader wont load correctly.

2nd, Install the requirements and wait until it has finished.

3rd, Install the peekhub installer and you should be good to go!

Happy beaming :)
